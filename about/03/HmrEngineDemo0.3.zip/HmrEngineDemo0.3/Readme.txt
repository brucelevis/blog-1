Hammer Engine v0.3 demo 
December 2005 - by Sepul - http://www.sepul.net

Hammer is a simple FPS engine, written entirely from scratch, and has it's own editor, exporters and tools.
I've started this project on March 2005, and is currently in progress, totally written in C++, under Windows and uses DirectX. I'm not planning to do any multi-platform support, cuz this is my first attempt at engine development and the code may get complicated for me and also takes time.

History :

Version 0.3 - dec.2005

- Dropped fixed pipeline completely except debugging stuff, and changed to vertex/pixel shaders with efficient scene sorter.
- Per Pixel lighting and bump mapping.
- Slow Software skeletal animation changed to Hardware accelerated skeletal animation and animation blending.
- Supports wide range of graphics cards with different effects / shaders, from vs_1_1 to vs_2_0 / ps_2_0.
- Added Key framed object animation.
- Improved console system.
- Support for multiple resolutions and fullscreen mode.
- Support for Transparent / alpha blended objects.
- Skybox.
- Material shaders with custom INI like file format.
- Material effects , color/alpha blending, texture animation, Environmental mapping (spherical and planar) , using material shaders
- Efficient Light culling system using octrees.
- Fixed major PVS / BSP bugs, and improved the performance of the PVS calculation by using flooding algorithms.
- Fixed some Editor minor bugs and added material and lighting editor for each asset.
- Vastly improved rendering performance.
- LOD (Level of Detail) for scene geometry
- Bump LOD

Version 0.1 - sep.2005

- Direct3D9 Renderer
- 3dsmax6+ exporter for creating level geometry
- Easy-to-use level editor which includes level geometry compiler, object placement, built-in object 	editor and animation viewer
- Custom bitmap fonts
- Skeletal animation and Animation blending
- BSP/PVS scene occlusion combined with frustum culling
- Direct Input support
- Node tree scene structure with support for object attachment and node animation.
- Simple customizable particle system using vertex shaders
- Lightmaps and static shadows
- Advanced collision detection system using AABB trees*
- Custom math library and classes (Matrix, Vector, Quaternion, Collision, etc.)
- Object oriented design (C++)
- Custom DirectX (.x) file parser


* please report any bugs or suggestions to sep.tagh@gmail.com and check out http://www.sepul.net for later updates.

thanks
sepul
